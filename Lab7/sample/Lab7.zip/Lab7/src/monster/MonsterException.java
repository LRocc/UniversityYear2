package monster;

@SuppressWarnings("serial")
public class MonsterException extends Exception {

	public MonsterException (String message) {
		super(message);
	}
}
