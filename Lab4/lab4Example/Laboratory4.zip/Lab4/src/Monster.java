import java.util.Arrays;

public class Monster {

	private String type;
	private int hitPoints;
	private int attackPoints;
	private String[] weaknesses;

	public Monster(String type, int hitPoints, int attackPoints, String[] weaknesses) {
		this.type = type;
		this.hitPoints = hitPoints;
		this.attackPoints = attackPoints;
		this.weaknesses = weaknesses;
	}

	// Getters and setters
	public int getHitPoints() {
		return hitPoints;
	}

	public int getAttackPoints() {
		return attackPoints;
	}

	public String getType() {
		return this.type;
	}

	public boolean attack(Monster otherMonster) {
		// A monster cannot attack itself
		if (otherMonster == this) {
			return false;
		}

		// A monster cannot attack or be attacked if it is knocked out
		if (this.hitPoints <= 0 || otherMonster.getHitPoints() <= 0) {
			return false;
		}

		// Check if the other monster is weak against our type
		boolean otherIsWeak = otherMonster.isWeakAgainst(type);
		int pointsToRemove = (otherIsWeak) ? this.attackPoints + 20 : this.attackPoints;
		otherMonster.removeHitPoints(pointsToRemove);
		return true;
	}
	
	public boolean isWeakAgainst(String otherType) {
		for (String weakness : this.weaknesses) {
			if (weakness.equals(otherType)) {
				return true;
			}
		}
		return false;
	}

	private void removeHitPoints(int points) {
		this.hitPoints -= points;
		if (hitPoints <= 0) {
			// Monster is knocked out
			hitPoints = 0;
		}
	}

	@Override
	public String toString() {
		return "Monster [type=" + type + ", hitPoints=" + hitPoints + ", attackPoints=" + attackPoints + ", weaknesses="
				+ Arrays.toString(weaknesses) + "]";
	}

	public static void main(String[] args) {
		Monster fireMonster = new Monster("Fire", 200, 100, new String[] { "Water" });
		Monster waterMonster = new Monster("Water", 120, 50, new String[] { "Fire", "Electric" });
		Monster electricMonster = new Monster("Electric", 150, 10, new String[0]);

		waterMonster.attack(fireMonster); // Should return true
		System.out.println(waterMonster.getHitPoints()); // 120
		System.out.println(fireMonster.getHitPoints()); // 130

		fireMonster.attack(waterMonster); // Should return true
		System.out.println(waterMonster.getHitPoints()); // 0

		fireMonster.attack(fireMonster); // Should return false
		System.out.println(fireMonster.getHitPoints()); // 130

		fireMonster.attack(electricMonster); // Should return true
		System.out.println(electricMonster.getHitPoints()); // 50

		waterMonster.attack(fireMonster); // Should return false
	}

}
